public interface Constants extends ScannerConstants
{
    int EPSILON  = 0;
    int DOLLAR   = 1;

    int t_cint = 2;
    int t_cfloat = 3;
    int t_cchar = 4;
    int t_cstring = 5;
    int t_linha = 6;
    int t_bloco = 7;
    int t_TOKEN_8 = 8; //"!"
    int t_TOKEN_9 = 9; //"=="
    int t_TOKEN_10 = 10; //"="
    int t_TOKEN_11 = 11; //"!="

}
